package com.relationship.customer.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.relationship.customer.entity.Customer;

@Service

public interface CustomerService {
	
	
		public List<Customer> findAll();

		public Customer findById(int custId);

		public void save(Customer theCustomer);

		public void deleteById(int theCustomer);

		public List<Customer> searchBy(String firstName, String LastName);

		

	}




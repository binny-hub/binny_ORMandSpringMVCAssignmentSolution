package com.relationship.customer.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customer")
public class Customer {
      
	  @Id
	  @GeneratedValue(strategy= GenerationType.IDENTITY)
	  @Column(name="custId")
		private int custId;


		@Column(name="firstName")
		private String firstName;

		@Column(name="lastName")
		private String lastName;

		@Column(name="email")
		private String emailId;


		// define constructors

		public Customer()
		{

		}


		public int getCustId() {
			return custId;
		}


		public void setCustId(int custId) {
			this.custId = custId;
		}


		public String getFirstName() {
			return firstName;
		}


		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}


		public String getLastName() {
			return lastName;
		}


		public void setLastName(String lastName) {
			this.lastName = lastName;
		}


		public String getEmailId() {
			return emailId;
		}


		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}


		public Customer(String firstName, String lastName, String emailId) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.emailId = emailId;
		}


		@Override
		public String toString() {
			return "Customer [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", emailId="
					+ emailId + "]";
		}
		
	
	
	
}

package com.relationship.customer.controller;


import com.relationship.customer.entity.Customer;
import com.relationship.customer.service.CustomerService;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/Customer")
public class CustomerController {
	
		@Autowired
		private CustomerService customerService;

		// add mapping for "/list"

		@RequestMapping("/list")
		public String listCustomers(Model theModel) {

			// get Customers from db
			List<Customer> theCustomers = customerService.findAll();

			// add to the spring model
			theModel.addAttribute("Customer", theCustomers);

			return "list-customers";
		}

		@RequestMapping("/showFormForAdd")
		public String showFormForAdd(Model theModel) {

			// create model attribute to bind form data
			Customer theCustomer = new Customer();

			theModel.addAttribute("Customers", theCustomer);

			return "customer-form";
		}

		@RequestMapping("/showFormForUpdate")
		public String showFormForUpdate(@RequestParam("custId") int theId, Model theModel) {

			// get the Student from the service
			Customer theCustomer = customerService.findById(theId);

			// set Student as a model attribute to pre-populate the form
			theModel.addAttribute("Customers", theCustomer);

			// send over to our form
			return "Customer-form";
		}

		@PostMapping("/save")
		public String saveCustomer(@RequestParam("custId") int custId, @RequestParam("firstName") String firstName,
				@RequestParam("lastName") String lastName, @RequestParam("emailId") String emailId)
				 
			{

			System.out.println(custId);
			Customer theCustomer;
			if (custId != 0) {
				theCustomer = customerService.findById(custId);
				theCustomer.setFirstName(firstName);
				theCustomer.setLastName(lastName);
				theCustomer.setEmailId(emailId);
				} 
			else
				theCustomer = new Customer(firstName, lastName, emailId);
			// save the customer
			customerService.save(theCustomer);

			// use a redirect to prevent duplicate submissions
			return "redirect:/Customer/list";
			}

		@RequestMapping("/delete")
			public String delete(@RequestParam("custId") int theId) {

				// delete the Customer
		     customerService.deleteById(theId);

				// redirect to /Customers/list
				return "redirect:/Customer/list";

		}


		@RequestMapping("/search")
			public String search(@RequestParam("firstName") String firstName,@RequestParam("lastName") String lastName,
						Model theModel) {

				// check names, if both are empty then just give list of all Books

				if (firstName.trim().isEmpty() && lastName.trim().isEmpty()) {
					return "redirect:/Customer/list";
				}
				else {
					// else, search by first name and last name
					List<Customer> theCustomer = customerService.searchBy(firstName, lastName);

					// add to the spring model
					theModel.addAttribute("Customers", theCustomer);

					// send to list-Books
					return "list-customers";
				}

			}
			
	}




package com.relationship.customer.service;


import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.relationship.customer.entity.Customer;

@Repository

public class CustomerServiceImpl {
	
	private SessionFactory sessionFactory;

	// create session
	private Session session;

	@Autowired
	
	CustomerServiceImpl(SessionFactory sessionFactory)
	{  
		this.sessionFactory=sessionFactory;
		try {
			session = sessionFactory.getCurrentSession();
		} 
		
		catch (HibernateException e) {
			session = sessionFactory.openSession();
		}


	}
	
	
	//@Transactional
	//@Override
	public List<Customer> findAll(){
		Transaction transaction = session.beginTransaction();
		List<Customer> customer = session.createQuery("from Customer").list();
		
		transaction.commit();
		return customer;
	}
	
	//@Override
	public void save(Customer customer) {
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(customer);
		transaction.commit();
		
		
	}
	
	//@Override
	public void deleteById(int custId) {
		Transaction transaction = session.beginTransaction();
		Customer customer = session.get(Customer.class, custId);
		session.delete(customer);
		transaction.commit();
		
	}
	
	//@Override
	public Customer findById(int custId) {
		Transaction transaction = session.beginTransaction();
		Customer customer = session.get(Customer.class, custId);
		
		transaction.commit();
		return customer;
		
	}


	//@Override
	public List<Customer> searchBy(String firstName, String LastName) {
		// TODO Auto-generated method stub
		return null;
	}

  

}
